﻿using Microsoft.AspNetCore.Mvc;
using Sample.Interface;
using Sample.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sample.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class AuthController : ControllerBase
    {
        private IAuthenticateService _authenticateService;
        public AuthController(IAuthenticateService authenticateService) 
        {
            _authenticateService = authenticateService;
        }
        [HttpPost]
        public IActionResult Sign([FromBody]User usr)
        {
            var user = _authenticateService.Authenticate(usr.UserName, usr.Password);
            if (user == null)
                return BadRequest();
            return Ok(user);
        }
    }
}
