﻿using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Sample.Interface;
using Sample.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sample.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class CalculatorController : ControllerBase
    {
        private IConfiguration _config;
        private ICalculatorServie _calculatorService;

        public CalculatorController(IConfiguration config, ICalculatorServie calculatorService)
        {
            _config = config;
            _calculatorService = calculatorService;
        }

        [HttpPost]
        //[Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        public IActionResult Calculate([FromBody] CalculateRequestModel calculateRequest)
        {
            try
            {
                if (calculateRequest != null)
                {
                    if (calculateRequest.Price == 0 || calculateRequest.Weight == 0)
                        return BadRequest();
                    var result = _calculatorService.Calculate(calculateRequest);
                    return Ok(result);
                }
                else
                {
                    return BadRequest();
                }
            }
            catch (Exception)
            {
                return null;
            }

        }


    }

}
