﻿using Sample.Interface;
using Sample.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sample.Service
{
    public class CalculatorService : ICalculatorServie
    {
        public int Calculate(CalculateRequestModel calculateRequest)
        {
            int result = 0;
            if (calculateRequest.Percentage != null || calculateRequest.Percentage != null)
            {
                result = calculateRequest.Price * calculateRequest.Weight;
            }
            else
            {
                var total = calculateRequest.Price * calculateRequest.Weight;
                result = total - ((total * (int)calculateRequest.Percentage) / 100);
            }
            return result;
        }
    }
}
