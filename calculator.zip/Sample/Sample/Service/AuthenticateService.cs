﻿using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using Sample.Interface;
using Sample.Models;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace Sample.Service
{
    public class AuthenticateService : IAuthenticateService
    {
        private readonly IConfiguration _config;
        public AuthenticateService(IConfiguration config)
        {
            _config = config;
        }
        private List<User> Users = new List<User>() { new User { UserName = "rinshad", Password = "password" } };
        public UserResponse Authenticate(string userName, string password)
        {
            var user = Users.Where(x => x.UserName == userName && x.Password == password).FirstOrDefault();
            if (user == null)
                return null;

            var tokenHandler = new JwtSecurityTokenHandler();
            var secretKey = Encoding.UTF8.GetBytes(_config["JsonWebTokenKeys:IssuerSigningKey"]); /*_config["JsonWebTokenKeys:IssuerSigningKey"]*/
            var tokeOptions = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(
                 new Claim[]
                 {
                    new Claim("Issuer",_config["JsonWebTokenKeys:ValidIssuer"]),
                    new Claim("Admin", "true"),
                    new Claim(ClaimTypes.Version, "1")
                 }),
                Expires = DateTime.Now.AddMinutes(5),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(secretKey), SecurityAlgorithms.HmacSha256)

            };

            var token = tokenHandler.CreateToken(tokeOptions);          
            user.Password = null;
            UserResponse userResponse = new UserResponse()
            {
                Token = tokenHandler.WriteToken(token),
                UserName = user.UserName
            };
            return userResponse;
        }
    }
}
